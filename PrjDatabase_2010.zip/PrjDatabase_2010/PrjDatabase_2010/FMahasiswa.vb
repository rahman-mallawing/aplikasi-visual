﻿Public Class FMahasiswa

    Private Sub TMahasiswaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TMahasiswaBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TMahasiswaBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.AKADEMIKDataSet)

    End Sub

    Private Sub FMahasiswa_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'AKADEMIKDataSet.TMahasiswa' table. You can move, or remove it, as needed.
        Me.TMahasiswaTableAdapter.Fill(Me.AKADEMIKDataSet.TMahasiswa)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cat As String = ComboBox1.SelectedItem
        Dim val As String = TextBox1.Text

        If cat = "" Then
            TMahasiswaBindingSource.Filter = String.Empty
        Else
            TMahasiswaBindingSource.Filter = cat & " LIKE '*" & val & "*'"
        End If

    End Sub
End Class