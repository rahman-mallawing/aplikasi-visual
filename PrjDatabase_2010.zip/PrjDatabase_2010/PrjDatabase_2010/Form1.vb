﻿Public Class FLogin

    Private Sub TUserBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TUserBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.AKADEMIKDataSet)

    End Sub

    Private Sub FLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'AKADEMIKDataSet.TUser' table. You can move, or remove it, as needed.
        Me.TUserTableAdapter.Fill(Me.AKADEMIKDataSet.TUser)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim username, password As String
        username = TextBox1.Text
        password = TextBox2.Text
        Dim jumlah As Integer = 0
        jumlah = TUserTableAdapter.PeriksaUser(AKADEMIKDataSet.TUser, username, password)
        If jumlah > 0 Then
            FUtama.Text = "Aplikasi Akademik-[User::" + username + "]"
            Me.Close()
        Else
            MessageBox.Show("Username atau password salah")
        End If
    End Sub

    Private Sub BtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        End
    End Sub
End Class
